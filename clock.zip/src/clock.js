import { bind } from "svelte/internal"

export class Clock {
    constructor(hour, minute) {
        
        this.Hour = hour
        this.Minute = minute
        
        this.AlarmHour = null
        this.AlarmMinute = null
        
        this.alarmIsActive = false
        this.alarmTriggered = false

        this.hexTime = "#000000"

        if (hour >= 24 || hour < 0) {
            throw RangeError("hour value must be >= 0 and < 24");
        }
        
        if (minute >= 60 || minute < 0) { 
            throw RangeError("minute value must be >= 0 and < 60");
        }
    }
    
    tick() {    
        
        this.Minute += 1;
        
        if (this.Minute == 60) {
            this.Hour += 1;
            this.Minute = 0
        }
        if (this.Hour == 24) {
            this.Hour = 0;
        }

        console.log(this.Result(this.Hour) + ":" + this.Result(this.Minute))

        if (this.AlarmHour <= 23 && this.AlarmHour >= 0 && this.AlarmMinute <= 59 && this.AlarmMinute >= 0) {
            if (this.AlarmHour !=  null && this.AlarmMinute != null) {
                if (this.AlarmHour == this.Hour && this.AlarmMinute == this.Minute) {
                    if (this.alarmIsActive == true) {
                        console.log("Alarm!!!")
                        this.alarmTriggered = true;
                    }
                } 
            }
        }
        this.timeAsHex()
    }

    IfAlarmIsTriggered() {
        if (this.AlarmHour <= 23 && this.AlarmHour >= 0 && this.AlarmMinute <= 59 && this.AlarmMinute >= 0) {
            if (this.AlarmHour !=  null && this.AlarmMinute != null) {
                if (this.AlarmHour <= this.Hour && this.AlarmMinute <= this.Minute) {
                    if (this.alarmIsActive == true) {
                        this.alarmTriggered = true;
                        console.log("Hasbulla is here")
                    }
                } 
            }
        }
        return false
    }

    Result(num) {
        if (num < 10) {
            return "0" + num
        } else {
            return num
        }
    }
    
    setAlarm(AlarmHour, AlarmMinute) {
        this.AlarmHour = AlarmHour;
        this.AlarmMinute = AlarmMinute;  
        this.alarmIsActive = true
    }
    
    activateAlarm() {
        this.alarmIsActive = true
    }

    deactivateAlarm() {
        this.alarmIsActive = false
        this.alarmTriggered = false
    }

    resetAlarm() {
        this.alarmTriggered = false
    }
    
    timeAsHex() {

        this.hexTime = `#${this.Result(this.Hour)}${this.Result(this.Minute)}00`
    }

}