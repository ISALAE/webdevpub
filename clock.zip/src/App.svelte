<script>
	import { fade } from 'svelte/transition';
	import { Clock } from "./clock";

	let clock = new Clock(0,0);
	clock.setAlarm()

	function tick() {
		clock.tick();
		clock = clock;
	}

	setInterval(tick, 1000);
</script>
	<body>
		{#if clock.alarmTriggered}
        	<p class="text" transition:fade>WAKE UP!!!</p>
   		{/if}
		<button on:click={tick} class="testtext buttonpos2" size="20"> Add Minutes! </button>
		<h1 class="text buttonpos">Clock: {clock.Result(clock.Hour) + ":" + clock.Result(clock.Minute)}</h1>
		
		<div id="bottom">
			<input bind:value={clock.AlarmHour} type="text" placeholder="Hour" required
			minlength="2" maxlength="2" size="20">
			<input bind:value={clock.AlarmMinute} type="text" placeholder="Minute" required
			minlength="2" maxlength="2" size="20">
			<button on:click={clock.resetAlarm()} class="testtext2" size="20"> Reset Alarm </button>
		</div>
		
		<div class="divrow">
			
			<!-- Clock 1 -->
			<svg viewBox="-50 -50 100 100">
				<circle r="30" style="fill: #000000; stroke: #000000;"/>
				{#each [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55] as minutes}
					<line
					style="stroke: #E6904E; stroke-width: 1.5px;"
					y1 = 27
					y2 = 30
					transform="rotate({30*minutes})"
					/>
					{#each [1, 2, 3, 4] as offset}
						<line
						style="stroke: #254E99; stroke-width: 1px;"
						y1 = 28
						y2 = 30
						transform="rotate({6 * (minutes+offset)})"
						/>
					{/each}
				{/each}
				<circle r="30" style="fill: none; stroke: #fff;"/>
				<circle r="30.5" style="fill: none; stroke: #000000;"/>
				<g transform="rotate({6*clock.Minute+180})">
					<line
					style="stroke: #fff; stroke-width: 1.35px;"
					y1 = 0
					y2 = 26.4
					/>
				</g>
				<g transform="rotate({0.5*clock.Minute+30*clock.Hour+180})">
					<line
					style="stroke: #fff; stroke-width: 1.35px;"
					y1 = 0
					y2 = 20
					/>
				</g>
				<circle r="0.26" style="fill: #fff; stroke: #fff;"/>
			</svg>
			
			<!-- Clock 2 -->
			<svg viewBox="-50 -50 100 100">
				<circle r="30" style="fill: {clock.hexTime};"/>
				<text x=-23 y=+3 style="font-size: 12px; fill: white; stroke: black; stroke-width: 0.25px;">{clock.hexTime}</text>
			</svg>
			
			<!-- Clock 3 -->
			<svg viewBox="-50 -50 100 100">
				<circle r="30" style="fill: #C62DFF; stroke: #000000;"/>
				{#each [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55] as minutes}
					<line
					style="stroke: #C62DFF; stroke-width: 1.5px;"
					y1 = 27
					y2 = 30
					transform="rotate({30*minutes})"
					/>
					{#each [1, 2, 3, 4] as offset}
						<line
						style="stroke: #C62DFF; stroke-width: 1px;"
						y1 = 28
						y2 = 30
						transform="rotate({6 * (minutes+offset)})"
						/>
					{/each}
				{/each}
					
				<circle r="30" style="fill: none; stroke: #9000C5;"/>
				<circle r="30.5" style="fill: none; stroke: #BA00FF;"/>
				<image src="./public/Horns.png" height="25" width="25" x="0" y="0"></image>
				<g transform="rotate({6*clock.Minute})">
					<line
					style="stroke: #9000C5; stroke-width: 1.35px;"
					y1 = -22.4
					y2 = 0
					/>
					<text x=-2.3 y=-23.25 style="fill: white; font-size: 7px">{clock.Minute}</text>
				</g>
				<g transform="rotate({0.5*clock.Minute+30*clock.Hour+180})">
					<line
					style="stroke: #9000C5; stroke-width: 1.35px;"
					y1 = 0
					y2 = 17
					/>
					<text x=1.75 y=18 rotate=180 style="fill: white; font-size: 7px">{clock.Hour}</text>
				</g>
				<circle r="0.26" style="fill: none; stroke: #9000C5;"/>
			</svg>
		</div>
	</body>

<style>
	.divrow {
		display:flex;
		justify-content: center;
		align-items: center;
		flex-direction: row;
		gap: 2%;
	}
	.buttonpos {
		position:fixed; bottom:10px; right: 40%;
	}
	.buttonpos2 {
		position:fixed; bottom:0px; right: 23.9%;
	}
	#bottom {
		position:fixed; bottom:0px; right: 31.25%;
	}
	.hreftext {
		text-align: center;
		font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		font-size: 30px;
		color: greenyellow;
		-webkit-text-stroke: 1px black;
	}
	:global(h2) {
		bottom: 0%;
		position: absolute;
		font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		font-size: 30px;
		color: white;
		-webkit-text-stroke: 1px black;
	}
	.border {
		border: 4mm ridge rgb(51, 255, 0);
	}
	:global(body) {
		background: url("BlackAndWhite.gif") no-repeat center center fixed;
		-webkit-background-size: cover;
  		-moz-background-size: cover;
 	 	-o-background-size: cover;
  		background-size: cover;
	}
	.ghost {
		visibility: hidden;
	}
	.text {
		font-size: 60px;
		font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		color: white;
		-webkit-text-stroke: 2px black;
		text-align: center;
	}
	.testtext {
		font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		
		color:white;
		-webkit-text-stroke: 0.35px black;
		background-color: white;
		animation-name: color-shift-AddMinutes;
		animation-duration: 3s;
		animation-iteration-count: infinite;
		animation-direction: alternate-reverse;
		
	}
	.testtext2 {
		font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		color: white;
		-webkit-text-stroke: 0.35px black;
		background-color: white;
		animation-name: color-shift-ResetAlarm;
		animation-duration: 3s;
		animation-iteration-count: infinite;
		animation-direction: alternate-reverse;
	}
	@media (max-width:1281px) {
		.divrow {		
			flex-direction: column;
		}
		.buttonpos {
			position: fixed;
			bottom: 70px;
			right: 60%;
			font-size: 33px;
		}
		.buttonpos2 {
			position: fixed; 
			bottom: 0px; 
			right: 14.7%;
		}
	}
	@keyframes color-shift-AddMinutes {
		from {background-color: white;}
		to {background-color: green;}
	}
	@keyframes color-shift-ResetAlarm {
		from {background-color: white;}
		to {background-color: red;}
	}
</style>